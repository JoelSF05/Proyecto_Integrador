# Upgrade Plan: sistema-arroz (20260525052744)

- **Generated**: 2026-05-25 05:27 UTC
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- Java 26.0.1: C:\Program Files\Java\jdk-26.0.1\bin (current system JDK used for verification)
- Java 21: not available (project target runtime; baseline verification skipped if exact JDK is unavailable)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (required by Step 1, no Maven installation detected)
- Maven Wrapper: present as `mvnw`/`mvnw.cmd`, but `.mvn/wrapper` metadata is missing, so the wrapper cannot be used without regeneration.

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260525052744
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime upgraded to the latest LTS version: Java 21

## Technology Stack

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| --------------------- | ------- | -------------- | ---------------- |
| Java runtime / `java.version` | 21 | 21 | Project already targets latest LTS runtime |
| Spring Boot starter parent | 4.0.6 | 4.0.6 | Already on a Java 21-compatible Spring Boot line |
| Maven | none installed | 3.9.0 | Required to build Java 21 projects if Maven Wrapper is unavailable |
| Maven Wrapper | `mvnw`/`mvnw.cmd` only | 3.9.0 | Wrapper metadata missing; cannot bootstrap Maven without regeneration |
| Spring Boot Test dependencies | invalid `*-test` starters | `spring-boot-starter-test` | Boot does not provide per-starter test artifacts; build may fail without fix |

## Derived Upgrades

- No Java runtime upgrade is required because the project already declares `java.version=21`.
- Maven installation is required for verification because no Maven runtime was detected and the existing wrapper metadata is missing.
- A test dependency correction may be required to allow `mvn test` to resolve and execute the suite successfully.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | `spring-boot-starter-data-jpa-test` | present | replace | `spring-boot-starter-test` | Boot does not provide artifact; needed for test resolution |
| pom.xml | `spring-boot-starter-thymeleaf-test` | present | remove | (not needed) | Invalid dependency declaration in Spring Boot 4.x project |
| pom.xml | `spring-boot-starter-validation-test` | present | remove | (not needed) | Invalid dependency declaration in Spring Boot 4.x project |
| pom.xml | `spring-boot-starter-webmvc-test` | present | remove | (not needed) | Invalid dependency declaration in Spring Boot 4.x project |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| pom.xml | dependency section | invalid test starter artifacts | replace with correct Spring Boot test starter | ensure test dependencies resolve and allow full-suite validation |

### Configuration Changes

No application configuration changes are required for the Java 21 runtime upgrade.

### CI/CD Changes

No CI/CD files were detected in the workspace; no changes required.

### Risks & Warnings

- **No Maven installation detected**: Build verification cannot proceed until Maven is installed or wrapper metadata is regenerated. Mitigation: install Maven in Step 1.
- **Missing Maven Wrapper metadata**: The `mvnw` script exists, but the required `.mvn/wrapper` directory is absent. Mitigation: use an installed Maven runtime for verification instead of the wrapper.
- **Project already targets Java 21**: This is the latest LTS and means no runtime upgrade is required. The work is primarily validation and build stabilization rather than a version bump.
- **Potential invalid test dependencies**: The current POM includes Boot test starters that likely do not exist. Mitigation: replace these with `spring-boot-starter-test` if compile/test resolution fails.

## Upgrade Steps

- Step 1: Install Maven and prepare the Java 21 validation environment
  - Rationale: No local Maven installation was detected, and the existing Maven wrapper metadata is missing, so a build tool is required before verification.
  - Changes to Make: Install Maven 3.9+ using the available installer tool; keep Java 26 available for verification with `java.version=21`.
  - Verification: `mvn -version`; expected result: Maven runs and reports Java 26 or Java 21 compatible runtime.

- Step 2: Baseline verification on current configuration
  - Rationale: Confirm the project is already targeting latest-LTS Java 21 and identify any build or test dependency issues before making changes.
  - Changes to Make: Run initial compile/test checks; do not modify source unless dependency resolution errors expose invalid starters.
  - Verification: `mvn clean compile test-compile -q`; expected result: either success or resolution failure from invalid test dependencies.

- Step 3: Correct test dependency declarations if needed and verify Java 21 build compatibility
  - Rationale: If Boot test starter artifacts are invalid, fix them so the project can compile and run tests under the existing Java 21 runtime target.
  - Changes to Make: Replace the invalid `*-test` dependencies with `spring-boot-starter-test` in `pom.xml` and keep the existing Java 21 target configuration.
  - Verification: `mvn clean test-compile -q`; expected result: compile succeeds.

- Step 4: Final validation with full test execution
  - Rationale: Confirm the project is fully compatible with Java 21 runtime and that the full test suite passes after any required POM fixes.
  - Changes to Make: Run the complete test suite on the validated configuration.
  - Verification: `mvn clean test`; expected result: 100% test pass rate.
